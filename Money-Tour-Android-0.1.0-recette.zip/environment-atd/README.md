# Essai ATD local — aucune interface native validée

Un seul démarrage de l’image officielle `system-images;android-35;aosp_atd;x86_64` a été tenté sans KVM : TCG/SwiftShader, 360 × 720, densité 160, 3 072 Mio et deux vCPU. **Android 15 / API 35 a terminé son démarrage en 443,6 secondes de surveillance**, dans la limite prévue.

L’APK canonique local a été installé : `Money-Tour-Android-0.1.0-debug.apk`, SHA-256 `177f45fce2127b5bfe21744340b26cdb34192b10de71bf2ab454f3faa73bd257`. Les journaux montrent les plugins enregistrés, le chargement de `https://localhost` et les événements natifs de démarrage/reprise.

WebView 124.0.6367.219 et LatinIME sont installés ; LatinIME est sélectionné. L’image slim ne fournit pas le service `phone`, le lanceur normal ni le package SystemUI normal.

La recette originale a échoué avant le lancement sur `svc data disable` : service absent (`results.json`, zéro contrôle réussi). Une copie ATD explicitement autorisée a seulement omis les commandes cellulaires impossibles, désactivé le Wi-Fi et conservé `noDefaults`/`paused.seq`. Aucun code produit ou fichier source n’a changé. Cette copie a expiré pendant la connexion CDP après 120 secondes (`adapted/results.json`, zéro contrôle réussi).

Le journal final montre un **crash du renderer WebView 2738, code 5**, puis la terminaison de l’application par Chromium à 22:39:04 UTC. La cause n’est pas établie ; la capture est noire. **Aucun contrôle d’interface ou de cycle de vie n’est accepté à partir de cet essai.**

À la demande du responsable, l’émulateur a été arrêté sans nouvelle tentative. La console a confirmé l’arrêt, puis le processus hôte est sorti avec le code 139. Aucun processus de cet essai ni aucune redirection ADB ne subsiste. Les essais de l’image Android complète avec KVM sont indépendants.

Voir `attempt-summary.json` pour le résultat structuré. Les rapports originaux, captures, inventaires, journaux de démarrage et `app-logcat.txt` restent conservés ; aucun échec n’a été remplacé par une réussite.
